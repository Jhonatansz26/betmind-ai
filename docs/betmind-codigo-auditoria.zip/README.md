# BetMind AI — Código y evidencia para auditoría externa

Paquete para el revisor (Claude). Contiene el código real del monorepo que pediste, datos de producción reales y los documentos de contexto.

## Contenido

### `docs/`
- `contexto-proyecto.md` — qué es BetMind, negocio, producto, flujo operativo (LEER PRIMERO).
- `auditoria-tecnica-2026.md` — sospechas del equipo, SIN VALIDAR (no confiar en ellas, verificar).
- `prompt-claude-auditoria.md` — el prompt de crítica con el formato de respuesta A-G y la regla de material adicional.

### `P0/` — lo pediste primero
| Archivo | Qué es |
|---|---|
| `odds_service.py` | Parseo de cuotas API-Football: throttle 6s, `best_odds = max(...)`, filtros hardcodeados (líneas ~200-470) |
| `poisson_engine.py` | Poisson bivariado + Dixon-Coles (ρ = −0.09 fijo), matriz de marcadores |
| `config_ml.py` | Parámetros hardcodeados del modelo: pesos, umbrales EV, rangos λ, ventaja local por liga |
| `sync_today_matches.py` | Job diario. **OJO:** importa `MatchFixtureScraper` que NO existe en el repo (verifica si el CI muere) |
| `daily_predictions.yml` | Workflow de GitHub Actions (cron cada 2h) |

### `P1/`
| Archivo | Qué es |
|---|---|
| `market_calculator.py` | Córneres (NB K=1.3), tarjetas, remates, O/U, BTTS, DNB |
| `prediction_orchestrator.py` | Pipeline completo: cache → DB → cuantitativo → LLM → persistencia → respuesta |
| `match_repository.py` | Dedup multi-proveedor (líneas 366-503), queries de forma/H2H/liga |
| `kelly.py` | Quarter-Kelly con clamps 0.25%-2% |
| `ticket_builder.py` | Modos EDGE/VALUE/BOLD, correlaciones, anti-cáscara |

### `P2/`
| Archivo | Qué es |
|---|---|
| `espn_provider.py` | ESPN público: schedules por equipo, scoreboard, errores silenciados |
| `football_data_provider.py` | football-data.org (solo PL/PD) |
| `provider_registry.py` | Cascada A→B→C |
| `clv_tracker.py` | CLV: cuota de cierre vs "apertura" del último sync |

### `evidencia/` — DATOS REALES DE PRODUCCIÓN (Supabase, agosto 2026)
| Archivo | Qué es |
|---|---|
| `estadisticas-produccion.json` | **RESUMEN CRÍTICO:** 798 partidos, 668 FINISHED, solo 139 con cuotas, 280 predicciones — TODAS con `value_score=0` y todos los mercados `INSUFFICIENT` (EV nulo). 269 análisis tácticos: 258 llama-3.1-8b, 11 llama-3.3-70b. Distribución completa de cuotas por mercado (1X2, corners, cards, shots). Muestra de odds reales de un partido. |
| `prediction_match_1855.json` | markets_json REAL persistido (54 mercados, todo INSUFFICIENT) + lambdas, índices, confianza |
| `prediction_match_1856.json` | Ídem, otro partido |
| `prediction_match_1857.json` | Ídem, otro partido |

**HALLAZGO DE DATOS (verifícalo):** ninguna predicción persistida tiene EV calculado. Las cuotas existen en `bookmaker_odds` (solo 139 de 798 partidos) pero el pipeline las persistió con `expected_value=null`. El EV solo se calcula on-the-fly en `tickets.py:_stored_market_rows` (NO incluido aquí — pídelo si lo necesitas).

### `dependencias/` — para que el código sea legible
Importaciones directas de los archivos P0/P1/P2, con la estructura de carpetas original: `services/providers/base_provider.py` (contrato RawFixture/RawTeam), `services/api_football.py`, `services/data_ingestion.py`, `services/llm_cascade.py`, `services/cache_service.py`, `services/team_normalizer.py`, repositories (`bookmaker_odd`, `tactical_analysis`, `league`, `team`), `config.py` (settings API), `core/enums.py` + `core/exceptions.py`, schemas (`prediction`, `ticket`), models (`match`, `bookmaker_odd`, `prediction`, `tactical_analysis`, `team`, `league`), paquete ML (`ev_calculator`, `strength_calculator`, `form_calculator`, `league_calibrator`, `prediction_pipeline`, schemas, `bet_builder_engine`, `bet_builder_patterns`) y `scripts/batch_predict.py`.

## Notas

- **NO hay resultados de backtesting** (item 13 de tu P2): no existe ningún reporte generado en el repo ni en producción. El backtesting es offline y no se ha corrido formalmente en este proyecto (solo tests unitarios). Si lo necesitas, dínoslo y te armamos una corrida.
- El `markets_json` real de los 3 partidos está en `evidencia/` (no incluimos el dump entero de la tabla por tamaño).
- No se incluyen secretos ni el `.env`. Los nombres de columnas/tablas en `evidencia/` son los reales.
- La carpeta `apps/api/engine/{corners_model,player_props_model,match_tension}.py` y `apps/api/services/scrapers/match_fixture_scraper.py` están referenciadas pero NO existen en el repo — verifica si algo los importa en runtime.
