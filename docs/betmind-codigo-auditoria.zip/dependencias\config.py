import logging
import json
from pathlib import Path
from typing import Annotated, Any

from pydantic import field_validator
from pydantic_settings import BaseSettings, NoDecode

logger = logging.getLogger(__name__)


def _sanitize_db_url(url: str) -> str:
    from urllib.parse import urlparse, urlunparse
    try:
        parsed = urlparse(url)
        host = parsed.hostname or "unknown"
        db_name = parsed.path.lstrip("/") if parsed.path else "unknown"
        scheme = parsed.scheme.split("+")[-1] if "+" in parsed.scheme else parsed.scheme
        return f"{scheme}://{host}/{db_name}"
    except Exception:
        return url.split("@")[-1] if "@" in url else url


def _find_env_files() -> list[Path]:
    """
    Busca archivos .env en multiples ubicaciones.
    Prioridad: apps/api/.env > betmind-ai/.env (raiz del monorepo)
    """
    env_files = []
    
    current_dir = Path(__file__).resolve().parent
    project_root = current_dir.parent.parent
    
    candidate_paths = [
        current_dir / ".env",
        project_root / ".env",
    ]
    
    for path in candidate_paths:
        if path.exists() and path.is_file():
            env_files.append(path)
            logger.debug(f"Found .env file at: {path}")
    
    if not env_files:
        logger.warning(
            f"No .env file found. Searched in: {[str(p) for p in candidate_paths]}"
        )
    
    return env_files


class Settings(BaseSettings):
    APP_NAME: str = "BetMind AI"
    APP_VERSION: str = "0.1.0"
    DEBUG: bool = False
    ALLOWED_ORIGINS: Annotated[list[str], NoDecode] = [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ]

    DATABASE_URL: str = "sqlite+aiosqlite:///./betmind.db"
    REDIS_URL: str = "redis://localhost:6379/0"

    DB_POOL_SIZE: int = 20
    DB_MAX_OVERFLOW: int = 10
    DB_POOL_TIMEOUT: int = 30

    API_FOOTBALL_KEY: str = ""
    FOOTBALL_DATA_KEY: str | None = None
    GROQ_API_KEY: str = ""
    GROQ_API_KEYS: str = ""
    ANTHROPIC_API_KEY: str | None = None
    GEMINI_API_KEY: str | None = None

    SECRET_KEY: str = "change-me-in-production"
    SUPABASE_JWT_SECRET: str | None = None
    SUPABASE_JWT_AUDIENCE: str = "authenticated"
    ALGORITHM: str = "HS256"
    # 7 days — no refresh token for MVP (conscious scope decision)
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 10080
    # Password-reset tokens use a hard-coded 30-minute TTL in auth_service.py
    ADMIN_API_KEY: str = ""
    # Frontend base URL used to build password-reset links
    FRONTEND_URL: str = "http://localhost:3000"

    # Email via Resend (https://resend.com). Leave unset for console fallback.
    RESEND_API_KEY: str | None = None
    EMAIL_FROM_ADDRESS: str = "no-reply@betmind.ai"

    # Generic SMTP (Gmail, SendGrid, etc.). Falls back to Resend then console.
    SMTP_SERVER: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USERNAME: str | None = None
    SMTP_PASSWORD: str | None = None

    EMAIL_STUB_SHOW_LINK: bool = False

    # Wompi integration. Keep all secrets in environment variables.
    WOMPI_BASE_URL: str = "https://sandbox.wompi.co/v1"
    WOMPI_PUBLIC_KEY: str = ""
    WOMPI_PRIVATE_KEY: str = ""
    WOMPI_INTEGRITY_SECRET: str = ""
    WOMPI_EVENTS_SECRET: str = ""
    WOMPI_MONTHLY_AMOUNT_CENTS: int = 2_990_000
    WOMPI_ANNUAL_AMOUNT_CENTS: int = 24_990_000
    SUBSCRIPTION_GRACE_DAYS: int = 3
    PENDING_PAYMENT_RECONCILE_DELAY_MINUTES: int = 10

    GROQ_TIMEOUT_SECONDS: float = 90.0
    GROQ_SINGLE_CALL_TIMEOUT: float = 25.0
    GROQ_NARRATIVE_TIMEOUT: float = 80.0

    model_config = {
        "env_file_encoding": "utf-8",
        "extra": "ignore",
        "case_sensitive": True,
    }

    @field_validator("DATABASE_URL", mode="before")
    @classmethod
    def normalize_database_url(cls, v: Any) -> str:
        """
        Normaliza DATABASE_URL para usar driver asincrono.
        Convierte postgresql:// o postgres:// a postgresql+asyncpg://
        """
        if not isinstance(v, str):
            return v
        
        v = v.strip()
        
        if v.startswith("postgres://"):
            v = v.replace("postgres://", "postgresql+asyncpg://", 1)
            logger.info("Normalized DATABASE_URL: postgres:// -> postgresql+asyncpg://")
        elif v.startswith("postgresql://"):
            v = v.replace("postgresql://", "postgresql+asyncpg://", 1)
            logger.info("Normalized DATABASE_URL: postgresql:// -> postgresql+asyncpg://")
        elif v.startswith("postgresql+asyncpg://"):
            pass
        elif v.startswith("sqlite"):
            pass
        else:
            logger.warning(f"Unknown DATABASE_URL scheme: {v[:50]}...")
        
        return v

    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def normalize_allowed_origins(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            # Supports comma-separated values and JSON arrays from deployment envs.
            try:
                decoded = json.loads(v)
                if isinstance(decoded, list):
                    return [str(origin).strip() for origin in decoded if str(origin).strip()]
            except json.JSONDecodeError:
                pass
            return [origin.strip() for origin in v.split(",") if origin.strip()]
        return v

    def __init__(self, **kwargs: Any):
        env_files = _find_env_files()
        
        if env_files:
            self.model_config["env_file"] = str(env_files[0])
            logger.info(f"Loading .env from: {env_files[0]}")
        else:
            logger.warning("No .env file found, using default values")
        
        super().__init__(**kwargs)

        if not self.DEBUG and self.SECRET_KEY == "change-me-in-production":
            raise ValueError(
                "SECRET_KEY must be changed when DEBUG=False; refusing to start in production"
            )
        
        logger.info(f"Using database at {_sanitize_db_url(self.DATABASE_URL)}")

    def get_groq_api_keys(self) -> list[str]:
        """
        Retorna lista de API keys de Groq.
        Prioriza GROQ_API_KEYS (lista separada por comas) sobre GROQ_API_KEY.
        """
        if self.GROQ_API_KEYS:
            keys = [k.strip() for k in self.GROQ_API_KEYS.split(",") if k.strip()]
            if keys:
                return keys
        if self.GROQ_API_KEY:
            return [self.GROQ_API_KEY]
        return []


settings = Settings()


# ─────────────────────────────────────────────────────────────────────────────
# CATALOGO MASTER DE LIGAS ACTIVAS
# match_type: "LEAGUE" | "KNOCKOUT_CUP"
# ─────────────────────────────────────────────────────────────────────────────

FEATURED_LEAGUES: dict[str, dict] = {
    # ========================= LATAM ======================================
    "liga_betplay": {
        "api_football_id": 239,
        "name": "Liga BetPlay Dimayor",
        "country": "Colombia",
        "match_type": "LEAGUE",
    },
    "copa_colombia": {
        "api_football_id": 241,
        "name": "Copa Colombia",
        "country": "Colombia",
        "match_type": "KNOCKOUT_CUP",
    },
    "liga_profesional_arg": {
        "api_football_id": 128,
        "name": "Liga Profesional",
        "country": "Argentina",
        "match_type": "LEAGUE",
    },
    "copa_arg": {
        "api_football_id": 130,
        "name": "Copa de la Liga Profesional",
        "country": "Argentina",
        "match_type": "KNOCKOUT_CUP",
    },
    "serie_a_bra": {
        "api_football_id": 71,
        "name": "Serie A",
        "country": "Brasil",
        "match_type": "LEAGUE",
    },
    "serie_b_bra": {
        "api_football_id": 72,
        "name": "Serie B",
        "country": "Brasil",
        "match_type": "LEAGUE",
    },
    "copa_do_brasil": {
        "api_football_id": 73,
        "name": "Copa do Brasil",
        "country": "Brasil",
        "match_type": "KNOCKOUT_CUP",
    },
    "liga_mx": {
        "api_football_id": 262,
        "name": "Liga MX",
        "country": "Mexico",
        "match_type": "LEAGUE",
    },
    "mls": {
        "api_football_id": 253,
        "name": "Major League Soccer",
        "country": "USA",
        "match_type": "LEAGUE",
    },
    "mls_open_cup": {
        "api_football_id": 254,
        "name": "US Open Cup",
        "country": "USA",
        "match_type": "KNOCKOUT_CUP",
    },
    "libertadores": {
        "api_football_id": 13,
        "name": "CONMEBOL Libertadores",
        "country": "Sudamerica",
        "match_type": "KNOCKOUT_CUP",
    },
    "sudamericana": {
        "api_football_id": 11,
        "name": "CONMEBOL Sudamericana",
        "country": "Sudamerica",
        "match_type": "KNOCKOUT_CUP",
    },
    "liga_pro_ecu": {
        "api_football_id": 275,
        "name": "Liga Pro",
        "country": "Ecuador",
        "match_type": "LEAGUE",
    },
    "primera_chile": {
        "api_football_id": 274,
        "name": "Primera Division",
        "country": "Chile",
        "match_type": "LEAGUE",
    },
    "liga_1_peru": {
        "api_football_id": 281,
        "name": "Liga 1 Peru",
        "country": "Peru",
        "match_type": "LEAGUE",
    },
    # ========================= EUROPA TOP =================================
    "premier_league": {
        "api_football_id": 39,
        "name": "Premier League",
        "country": "England",
        "match_type": "LEAGUE",
    },
    "efl_championship": {
        "api_football_id": 40,
        "name": "EFL Championship",
        "country": "England",
        "match_type": "LEAGUE",
    },
    "laliga": {
        "api_football_id": 140,
        "name": "LaLiga",
        "country": "Spain",
        "match_type": "LEAGUE",
    },
    "laliga_hypermotion": {
        "api_football_id": 141,
        "name": "LaLiga Hypermotion",
        "country": "Spain",
        "match_type": "LEAGUE",
    },
    "bundesliga": {
        "api_football_id": 78,
        "name": "Bundesliga",
        "country": "Germany",
        "match_type": "LEAGUE",
    },
    "serie_a": {
        "api_football_id": 135,
        "name": "Serie A",
        "country": "Italy",
        "match_type": "LEAGUE",
    },
    "ligue_1": {
        "api_football_id": 61,
        "name": "Ligue 1",
        "country": "France",
        "match_type": "LEAGUE",
    },
    "eredivisie": {
        "api_football_id": 88,
        "name": "Eredivisie",
        "country": "Netherlands",
        "match_type": "LEAGUE",
    },
    "ucl": {
        "api_football_id": 2,
        "name": "UEFA Champions League",
        "country": "Europa",
        "match_type": "KNOCKOUT_CUP",
    },
    "uel": {
        "api_football_id": 3,
        "name": "UEFA Europa League",
        "country": "Europa",
        "match_type": "KNOCKOUT_CUP",
    },
    "uecl": {
        "api_football_id": 848,
        "name": "UEFA Conference League",
        "country": "Europa",
        "match_type": "KNOCKOUT_CUP",
    },
}

FEATURED_LEAGUE_IDS: list[int] = [
    league["api_football_id"] for league in FEATURED_LEAGUES.values()
]

# IDs de ligas que son eliminatorias/copas (para asignacion automatica de match_type)
KNOCKOUT_CUP_LEAGUE_IDS: set[int] = {
    info["api_football_id"]
    for info in FEATURED_LEAGUES.values()
    if info.get("match_type") == "KNOCKOUT_CUP"
}
